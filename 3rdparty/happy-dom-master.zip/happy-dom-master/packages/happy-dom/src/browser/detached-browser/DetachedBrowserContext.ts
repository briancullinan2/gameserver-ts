import type DetachedBrowser from './DetachedBrowser.js';
import DetachedBrowserPage from './DetachedBrowserPage.js';
import type IBrowserContext from '../types/IBrowserContext.js';
import type ICookieContainer from '../../cookie/ICookieContainer.js';
import CookieContainer from '../../cookie/CookieContainer.js';
import ResponseCache from '../../fetch/cache/response/ResponseCache.js';
import type IResponseCache from '../../fetch/cache/response/IResponseCache.js';
import type IPreflightResponseCache from '../../fetch/cache/preflight/IPreflightResponseCache.js';
import PreflightResponseCache from '../../fetch/cache/preflight/PreflightResponseCache.js';
import * as PropertySymbol from '../../PropertySymbol.js';
import type IECMAScriptModuleCachedResult from '../../module/types/IECMAScriptModuleCachedResult.js';

/**
 * Detached browser context used when constructing a Window instance without a browser.
 */
export default class DetachedBrowserContext implements IBrowserContext {
	public readonly pages: DetachedBrowserPage[];
	public readonly browser: DetachedBrowser;
	public readonly cookieContainer: ICookieContainer = new CookieContainer();
	public readonly responseCache: IResponseCache = new ResponseCache();
	public readonly preflightResponseCache: IPreflightResponseCache = new PreflightResponseCache();
	public readonly closed: boolean = false;
	public readonly [PropertySymbol.moduleCache]: Map<string, IECMAScriptModuleCachedResult> =
		new Map();

	/**
	 * Constructor.
	 *
	 * @param browser Browser.
	 */
	constructor(browser: DetachedBrowser) {
		this.browser = browser;
		this.pages = [];
		this.pages.push(new DetachedBrowserPage(this));
	}

	/**
	 * Aborts all ongoing operations and destroys the context.
	 */
	public async close(): Promise<void> {
		if (this.closed) {
			return;
		}

		if (this.browser.contexts[0] === this) {
			throw new Error(
				'Cannot close the default context. Use `browser.close()` to close the browser instead.'
			);
		}

		(<boolean>this.closed) = true;

		await Promise.all(this.pages.slice().map((page) => page.close()));

		const browser = this.browser;
		const index = browser.contexts.indexOf(this);

		if (index !== -1) {
			browser.contexts.splice(index, 1);
		}

		(<DetachedBrowserPage[]>this.pages) = [];
		this.cookieContainer.clearCookies();
		this.responseCache.clear();
		this.preflightResponseCache.clear();
	}

	/**
	 * Returns a promise that is resolved when all resources has been loaded, fetch has completed, and all async tasks such as timers are complete.
	 *
	 * @returns Promise.
	 */
	public async waitUntilComplete(): Promise<void> {
		await Promise.all(this.pages.map((page) => page.waitUntilComplete()));
	}

	/**
	 * Aborts all ongoing operations.
	 */
	public abort(): Promise<void> {
		return new Promise((resolve, reject) => {
			if (!this.pages.length) {
				resolve();
				return;
			}
			Promise.all(this.pages.slice().map((page) => page.abort()))
				.then(() => resolve())
				.catch((error) => reject(error));
		});
	}

	/**
	 * Creates a new page.
	 *
	 * @param [opener] Opener.
	 * @returns Page.
	 */
	public newPage(): DetachedBrowserPage {
		const page = new DetachedBrowserPage(this);
		this.pages.push(page);
		return page;
	}
}
