import type IOptionalServerRendererConfiguration from './types/IOptionalServerRendererConfiguration.js';
import type IServerRendererItem from './types/IServerRendererItem.js';
import { Worker } from 'worker_threads';
import type IServerRendererResult from './types/IServerRendererResult.js';
import ServerRendererLogLevelEnum from './enums/ServerRendererLogLevelEnum.js';
import type IServerRendererConfiguration from './types/IServerRendererConfiguration.js';
import ServerRendererConfigurationFactory from './utilities/ServerRendererConfigurationFactory.js';
import Path from 'path';
import Inspector from 'node:inspector';
import ServerRendererBrowser from './ServerRendererBrowser.js';
// eslint-disable-next-line import/no-named-as-default
import Chalk from 'chalk';
import ServerRendererModeEnum from './enums/ServerRendererModeEnum.js';

interface IWorkerWaitingItem {
	items: IServerRendererItem[];
	resolve: (results: IServerRendererResult[]) => void;
	reject: (error: Error) => void;
}

/**
 * Server renderer.
 */
export default class ServerRenderer {
	#configuration: IServerRendererConfiguration;
	#workerPool: { busy: Worker[]; free: Worker[]; waiting: IWorkerWaitingItem[] } = {
		busy: [],
		free: [],
		waiting: []
	};
	#browser: ServerRendererBrowser | null = null;

	/**
	 * Constructor.
	 *
	 * @param configuration Configuration.
	 */
	constructor(configuration?: IOptionalServerRendererConfiguration) {
		this.#configuration = ServerRendererConfigurationFactory.createConfiguration(configuration);

		if (this.#configuration.worker.disable && this.#configuration.inspect) {
			Inspector.open();
			Inspector.waitForDebugger();
		}
	}

	/**
	 * Server renders URLs or HTML strings.
	 *
	 * @param [renderItems] List render items. Each item can be a URL string or an object specifying the URL or HTML string along with additional options.
	 * @param [options] Options.
	 * @param [options.keepAlive] Keep the workers and browser alive. This is useful when using the renderer in a server. The workers can be closed with the `close()` method.
	 */
	public async render(
		renderItems?: Array<string | IServerRendererItem> | null,
		options?: { keepAlive?: boolean }
	): Promise<IServerRendererResult[]> {
		const startTime = performance.now();
		const configuration = this.#configuration;
		const items = renderItems || configuration.renderItems;
		const parsedItems: IServerRendererItem[] = [];

		if (!items || !items.length) {
			if (configuration.logLevel >= ServerRendererLogLevelEnum.info) {
				// eslint-disable-next-line no-console
				console.log(Chalk.bold(`\nNo URLs to render\n`));
			}
			return [];
		}

		for (const item of items) {
			if (typeof item === 'string') {
				parsedItems.push({ url: item });
			} else {
				parsedItems.push({
					url: item.url,
					html: item.html,
					outputFile: item.outputFile
						? Path.join(configuration.outputDirectory, item.outputFile)
						: null,
					headers: item.headers ?? null
				});
			}
		}

		if (configuration.logLevel >= ServerRendererLogLevelEnum.info) {
			if (configuration.inspect) {
				// eslint-disable-next-line no-console
				console.log(Chalk.blue(Chalk.bold(`\n🔍 Inspector enabled`)));
			}

			if (configuration.debug) {
				// eslint-disable-next-line no-console
				console.log(Chalk.blue(Chalk.bold(`\n🔨 Debug mode enabled`)));
			}

			// eslint-disable-next-line no-console
			console.log(
				Chalk.bold(
					`\nRendering ${parsedItems.length} page${parsedItems.length > 1 ? 's' : ''}...\n`
				)
			);
		}

		let results: IServerRendererResult[] = [];

		if (!configuration.cache.disable && configuration.cache.warmup) {
			const item = parsedItems.shift();
			if (item) {
				if (configuration.logLevel >= ServerRendererLogLevelEnum.info) {
					// eslint-disable-next-line no-console
					console.log('\nWarming up cache...\n');
				}

				results = results.concat(await this.#runInWorker([item]));

				if (configuration.logLevel >= ServerRendererLogLevelEnum.info) {
					// eslint-disable-next-line no-console
					console.log('\nCache warmup complete.\n');
				}
			}
		}

		if (parsedItems.length) {
			const promises = [];

			while (parsedItems.length) {
				const maxConcurrency =
					configuration.render.mode === ServerRendererModeEnum.page
						? 1
						: configuration.render.maxConcurrency;
				const chunk = parsedItems.splice(0, maxConcurrency);
				promises.push(
					this.#runInWorker(chunk).then((chunkResults) => {
						results = results.concat(chunkResults);
					})
				);
			}

			await Promise.all(promises);
		}

		if (configuration.logLevel >= ServerRendererLogLevelEnum.info) {
			const time = (performance.now() - startTime) / 1000;
			const minutes = Math.floor(time / 60);
			const seconds = Math.round((time % 60) * 100) / 100;
			// eslint-disable-next-line no-console
			console.log(
				Chalk.bold(
					`\nRendered ${items.length} page${items.length > 1 ? 's' : ''} in ${
						minutes ? `${minutes} minutes and ` : ''
					}${seconds} seconds\n`
				)
			);
		}

		if (!options?.keepAlive) {
			await this.close();
		}

		return results;
	}

	/**
	 * Closes the workers and browser.
	 */
	public async close(): Promise<void> {
		for (const worker of this.#workerPool.busy) {
			worker.terminate();
		}

		for (const worker of this.#workerPool.free) {
			worker.terminate();
		}

		this.#workerPool.busy = [];
		this.#workerPool.free = [];
		this.#workerPool.waiting = [];

		if (this.#browser) {
			await this.#browser.close();
			this.#browser = null;
		}
	}

	/**
	 * Runs in a worker.
	 *
	 * @param items Items.
	 */
	#runInWorker(items: IServerRendererItem[]): Promise<IServerRendererResult[]> {
		const configuration = this.#configuration;

		if (configuration.worker.disable) {
			if (configuration.render.mode === ServerRendererModeEnum.page) {
				throw new Error(
					'Page rendering mode cannot be used when worker threads are disabled. Please enable worker threads or use browser rendering mode.'
				);
			}

			if (!this.#browser) {
				this.#browser = new ServerRendererBrowser(configuration);
			}

			return this.#browser.render(items).then((results) => {
				this.outputResults(results);
				return results;
			});
		}

		return new Promise((resolve, reject) => {
			if (this.#workerPool.free.length === 0) {
				const maxConcurrency = configuration.inspect ? 1 : configuration.worker.maxConcurrency;
				if (this.#workerPool.busy.length >= maxConcurrency) {
					this.#workerPool.waiting.push({ items, resolve, reject });
					return;
				}
				const script =
					configuration.render.mode === ServerRendererModeEnum.page
						? 'ServerRendererPageWorker.js'
						: 'ServerRendererBrowserWorker.js';
				const worker = new Worker(new URL(script, import.meta.url), {
					workerData: {
						configuration: configuration
					}
				});
				this.#workerPool.free.push(worker);
			}

			if (this.#workerPool.free.length > 0) {
				const worker = this.#workerPool.free.pop()!;

				this.#workerPool.busy.push(worker);

				const done = (): void => {
					worker.off('message', listeners.message);
					worker.off('error', listeners.error);
					worker.off('exit', listeners.exit);

					this.#workerPool.busy.splice(this.#workerPool.busy.indexOf(worker), 1);
					this.#workerPool.free.push(worker);

					const waiting = this.#workerPool.waiting.shift();

					if (waiting) {
						this.#runInWorker(waiting.items).then(waiting.resolve).catch(waiting.reject);
					}
				};
				const listeners: {
					message: (message: any) => void;
					error: (error: Error) => void;
					exit: (code: number) => void;
				} = {
					message: (data) => {
						const results = <IServerRendererResult[]>data.results;
						this.outputResults(results);
						done();
						resolve(results);
					},
					error: (error: Error) => {
						if (configuration.logLevel >= ServerRendererLogLevelEnum.error) {
							for (const item of items) {
								// eslint-disable-next-line no-console
								console.error(Chalk.bold(Chalk.red(`\n❌ Failed to render page "${item.url}"\n`)));
								// eslint-disable-next-line no-console
								console.error(Chalk.red(error + '\n'));
							}
						}

						done();
						resolve(
							items.map((item) => ({
								url: item.url || null,
								content: null,
								status: 200,
								statusText: 'OK',
								headers: {},
								outputFile: item.outputFile ?? null,
								error: `${error.message}\n${error.stack}`,
								pageConsole: '',
								pageErrors: []
							}))
						);
					},
					exit: (code: number) => {
						// Closed intentionally, either by the user or with terminate()
						if (code === 0) {
							return;
						}

						this.#workerPool.busy.splice(this.#workerPool.busy.indexOf(worker), 1);

						for (const worker of this.#workerPool.free) {
							worker.terminate();
						}

						for (const worker of this.#workerPool.busy) {
							worker.terminate();
						}

						this.#workerPool.busy = [];
						this.#workerPool.free = [];
						this.#workerPool.waiting = [];

						reject(new Error(`Worker stopped with exit code ${code}`));
					}
				};

				worker.on('message', listeners.message);
				worker.on('error', listeners.error);
				worker.on('exit', listeners.exit);

				worker.postMessage({ items });
			}
		});
	}

	/**
	 * Outputs results to the console.
	 *
	 * @param results Results.
	 */
	private outputResults(results: IServerRendererResult[]): void {
		const configuration = this.#configuration;

		if (configuration.logLevel === ServerRendererLogLevelEnum.none) {
			return;
		}

		for (const result of results) {
			if (result.error) {
				if (configuration.logLevel >= ServerRendererLogLevelEnum.error) {
					// eslint-disable-next-line no-console
					console.error(Chalk.bold(Chalk.red(`\n❌ Failed to render page "${result.url}"\n`)));
					// eslint-disable-next-line no-console
					console.error(Chalk.red(result.error + '\n'));
				}
			} else if (result.pageErrors.length) {
				if (configuration.logLevel >= ServerRendererLogLevelEnum.warn) {
					// eslint-disable-next-line no-console
					console.log(Chalk.bold(`• Rendered page "${result.url}"`));
					// eslint-disable-next-line no-console
					console.log(
						Chalk.bold(
							Chalk.yellow(
								`\n⚠️ Warning! Errors where outputted to the browser when the page was rendered.\n`
							)
						)
					);
					// eslint-disable-next-line no-console
					for (const error of result.pageErrors) {
						// eslint-disable-next-line no-console
						console.log(Chalk.red(error + '\n'));
					}
				}
			} else {
				if (configuration.logLevel >= ServerRendererLogLevelEnum.info) {
					// eslint-disable-next-line no-console
					console.log(Chalk.bold(`• Rendered page "${result.url}"`));
				}
			}
			if (configuration.logLevel >= ServerRendererLogLevelEnum.debug && result.pageConsole) {
				// eslint-disable-next-line no-console
				console.log(Chalk.gray(result.pageConsole));
			}
		}
	}
}
